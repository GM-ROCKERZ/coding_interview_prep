
Feign example:
=============
A microservice is calling microservice B for 

public interface BserviceClient
{
  
}